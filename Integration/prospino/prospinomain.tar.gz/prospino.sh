#!/bin/sh

#tar -zxf prospinos.tar.gz
chmod +x *.run

file=`echo $1`

cp ${file}.slha prospino.in.les_houches

cm1="14TeV"
cm2="10TeV"
cm3="7TeV"
cm4="2TeV"

echo "Running at 7TeV "

./prospino_7.run >tmp.log 2>&1
touch prospino.dat
touch prospino.dat2
touch prospino.dat3

mv prospino.dat ${file}.${cm3}.dat
mv prospino.dat2 ${file}.${cm3}.dat2
mv prospino.dat3 ${file}.${cm3}.dat3

size=`stat -c %s tmp.log`

if [ $size -lt 100000000 ]; then
  cat tmp.log
else
  tail -500 tmp.log
fi

